import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.HashMap;
import java.util.Map;
import javax.swing.table.TableModel;

public class Calendar extends JPanel {
    public  JTable calendarTable;
    public Map<String, JButton> moodButtons = new HashMap<>();
    private JLabel monthLabel;
    private YearMonth currentMonth;
    private Map<LocalDate, String> moodHistory = new HashMap<>();
    private final Map<String, Color> moodColors = Map.of(
            "Happy", Color.YELLOW,
            "Sad", Color.BLUE,
            "Anxious", Color.ORANGE,
            "Stressed", Color.RED,
            "Uncertain", Color.BLACK
    );

    public Calendar() {
        initializeUI();
    }

    private void initializeUI() {
        setLayout(new BorderLayout());

        // Header panel for navigation
        JPanel headerPanel = new JPanel(new BorderLayout());
        JButton prevButton = new JButton("<");
        JButton nextButton = new JButton(">");
        monthLabel = new JLabel("", SwingConstants.CENTER);
        currentMonth = YearMonth.now();
        updateMonthLabel();

        prevButton.addActionListener(e -> changeMonth(-1));
        nextButton.addActionListener(e -> changeMonth(1));

        headerPanel.add(prevButton, BorderLayout.WEST);
        headerPanel.add(monthLabel, BorderLayout.CENTER);
        headerPanel.add(nextButton, BorderLayout.EAST);

        // Calendar table
        calendarTable = new JTable();
        calendarTable.setRowHeight(80);
        calendarTable.setDefaultRenderer(Object.class, new CalendarCellRenderer());
        updateCalendar();

        // Mood selection buttons
        JPanel moodPanel = new JPanel(new GridLayout(1, 5));
        for (String mood : moodColors.keySet()) {
            JButton moodButton = new JButton(mood);
            moodButton.setBackground(moodColors.get(mood));
            moodButton.setOpaque(true);
            moodButton.setForeground(Color.WHITE);
            moodButton.addActionListener(new MoodButtonListener(mood));
            moodPanel.add(moodButton);
            moodButtons.put(mood, moodButton);
        }
        

        add(headerPanel, BorderLayout.NORTH);
        add(new JScrollPane(calendarTable), BorderLayout.CENTER);
        add(moodPanel, BorderLayout.SOUTH);
    }

    private void updateMonthLabel() {
        monthLabel.setText(currentMonth.getMonth() + " " + currentMonth.getYear());
    }

    private void changeMonth(int offset) {
        currentMonth = currentMonth.plusMonths(offset);
        updateMonthLabel();
        updateCalendar();
    }

    private void updateCalendar() {
        DefaultTableModel model = new DefaultTableModel();
        model.setRowCount(0);

        String[] daysOfWeek = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        model.setColumnIdentifiers(daysOfWeek);

        LocalDate firstOfMonth = currentMonth.atDay(1);
        int startDayOfWeek = firstOfMonth.getDayOfWeek().getValue() % 7;
        int daysInMonth = currentMonth.lengthOfMonth();

        Object[] week = new Object[7];
        int day = 1;

        for (int i = 0; i < startDayOfWeek; i++) {
            week[i] = null;
        }

        for (int i = startDayOfWeek; i < 7; i++) {
            week[i] = day++;
        }
        model.addRow(week);

        while (day <= daysInMonth) {
            week = new Object[7];
            for (int i = 0; i < 7 && day <= daysInMonth; i++) {
                week[i] = day++;
            }
            model.addRow(week);
        }

        calendarTable.setModel(model);
    }

    private class MoodButtonListener implements ActionListener {
        private String mood;

        public MoodButtonListener(String mood) {
            this.mood = mood;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = calendarTable.getSelectedRow();
            int selectedColumn = calendarTable.getSelectedColumn();

            if (selectedRow != -1 && selectedColumn != -1) {
                Object value = calendarTable.getValueAt(selectedRow, selectedColumn);
                if (value != null) {
                    LocalDate selectedDate = currentMonth.atDay((int) value);
                    moodHistory.put(selectedDate, mood);
                    calendarTable.repaint();
                }
            } else {
                JOptionPane.showMessageDialog(Calendar.this, "Please select a day on the calendar.");
            }
        }
    }

    private class CalendarCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            JLabel cell = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            cell.setHorizontalAlignment(SwingConstants.CENTER);
            cell.setVerticalAlignment(SwingConstants.CENTER);

            if (value != null) {
                LocalDate date = currentMonth.atDay((int) value);
                String mood = moodHistory.get(date);
                if (mood != null) {
                    cell.setBackground(moodColors.get(mood));
                } else {
                    cell.setBackground(Color.WHITE);
                }
            } else {
                cell.setBackground(Color.LIGHT_GRAY);
            }

            return cell;
        }
    }
    public  int[] findDateIndices(String targetDate, TableModel model) {
        for (int row = 0; row < model.getRowCount(); row++) {
            for (int col = 0; col < model.getColumnCount(); col++) {
                Object cellValue = model.getValueAt(row, col);
                if (targetDate.equals(String.valueOf(cellValue))) {            
                    return new int[]{row, col}; // Return row and column indices
                }
            }
        }
        return null; // Date not found
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Mood Mosaic");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(600, 600);
            frame.add(new Calendar());
            frame.setVisible(true);
        });
    }
}
